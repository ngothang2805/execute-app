﻿// ==UserScript==
// @name        Visited Links Colorizer (Final v2.6 - Icon Support)
// @namespace   Cascade.VisitedLinks.Final
// @description Injects a direct CSS rule into all Shadow DOMs to color visited links, including text and SVG icons.
// @version     2.6
// @author      Cascade
// @match       http*://*/*
// @exclude     https://mail.live.com/*
// @grant       none
// @run-at      document-start
// ==/UserScript==

(function() {
    'use strict';

    //// CONFIGURATION ///////////////////////////////////////////////////////
    const VISITED_LINK_COLOR = 'LightCoral';
    const EXCLUDED_SITES = 'mail.live.com';
    ////////////////////////////////////////////////////////////////////////

    if (EXCLUDED_SITES.split(',').some(site => document.location.href.includes(site.trim()))) {
        return;
    }

    // This version targets both the 'color' for text and the 'fill' for SVG icons
    // inside visited links. This is crucial for modern sites like GitHub.
    const CSS_TEMPLATE = `
        a:visited, a:visited * {
            color: ${VISITED_LINK_COLOR} !important;
            fill: ${VISITED_LINK_COLOR} !important;
        }
    `;

    const injectedRoots = new WeakSet();

    function injectCss(rootNode) {
        if (!rootNode || injectedRoots.has(rootNode)) {
            return;
        }

        const style = document.createElement('style');
        style.textContent = CSS_TEMPLATE;
        rootNode.appendChild(style);
        injectedRoots.add(rootNode);
    }

    function processNode(node) {
        if (node.shadowRoot) {
            injectCss(node.shadowRoot);
        }
        // Recursively find all elements with shadow roots
        const allDescendants = node.querySelectorAll('*');
        for (const child of allDescendants) {
            if (child.shadowRoot) {
                injectCss(child.shadowRoot);
            }
        }
    }

    // Initial scan
    function initialScan() {
        // Inject into the main document's head
        injectCss(document.head);
        // Inject into all existing shadow roots
        processNode(document.documentElement);
    }

    // Use a MutationObserver to detect dynamically added elements with shadow roots.
    const observer = new MutationObserver((mutations) => {
        for (const mutation of mutations) {
            for (const node of mutation.addedNodes) {
                if (node.nodeType === Node.ELEMENT_NODE) {
                    processNode(node);
                }
            }
        }
    });

    // Start observing as soon as possible.
    observer.observe(document.documentElement, { childList: true, subtree: true });

    // Run the initial scan when the DOM is ready.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialScan);
    } else {
        initialScan();
    }

})();
